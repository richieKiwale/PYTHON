import os
import shutil
import socket
import getpass
import time
from datetime import datetime
import smtplib
from email.mime.text import MIMEText


# Close browsers before cleanup
os.system("taskkill /F /IM chrome.exe >nul 2>&1")
os.system("taskkill /F /IM msedge.exe >nul 2>&1")

# Allow Windows to release locked files
time.sleep(3)


username = getpass.getuser()

# Browser Profiles
chrome_profile = fr"C:\Users\{username}\AppData\Local\Google\Chrome\User Data\Profile 6"
edge_profile = fr"C:\Users\{username}\AppData\Local\Microsoft\Edge\User Data\Default"


status_list = []


def delete_file(file_path):
    try:
        if os.path.exists(file_path):
            os.remove(file_path)
            status_list.append(f"Deleted file: {file_path}")
        else:
            status_list.append(f"Not found: {file_path}")

    except Exception as e:
        status_list.append(f"Failed deleting {file_path}: {e}")


def delete_folder(folder_path):
    try:
        if os.path.exists(folder_path):
            shutil.rmtree(folder_path)
            status_list.append(f"Deleted folder: {folder_path}")
        else:
            status_list.append(f"Not found: {folder_path}")

    except Exception as e:
        status_list.append(f"Failed deleting {folder_path}: {e}")


# Chrome cleanup
chrome_files = [
    os.path.join(chrome_profile, "History"),
    os.path.join(chrome_profile, "History-journal"),
    os.path.join(chrome_profile, "Cookies"),
    os.path.join(chrome_profile, "Cookies-journal")
]

chrome_folders = [
    os.path.join(chrome_profile, "Cache"),
    os.path.join(chrome_profile, "Code Cache"),
    os.path.join(chrome_profile, "GPUCache"),
    os.path.join(chrome_profile, "Media Cache")
]


for file in chrome_files:
    delete_file(file)

for folder in chrome_folders:
    delete_folder(folder)



# Edge cleanup
edge_files = [
    os.path.join(edge_profile, "History"),
    os.path.join(edge_profile, "History-journal"),
    os.path.join(edge_profile, "Cookies"),
]

edge_folders = [
    os.path.join(edge_profile, "Cache"),
    os.path.join(edge_profile, "Code Cache"),
    os.path.join(edge_profile, "GPUCache")
]


for file in edge_files:
    delete_file(file)

for folder in edge_folders:
    delete_folder(folder)



# Email Configuration
gmail_user = "richard.kiwal3@gmail.com"

gmail_bcc=[
    "rich1.kiwale@gmail.com",
    "richardkiwale74@gmail.com",
    ]

# Use Gmail App Password
gmail_app_password = "nroijhaugdicjpmk"


computer_name = socket.gethostname()


message_body = f"""
Browser Cleanup Report

Date:
{datetime.now()}

Computer:
{computer_name}

User:
{username}


Cleanup Status:
--------------------------------

{chr(10).join(status_list)}

--------------------------------
Completed Successfully
"""


msg = MIMEText(message_body)

msg["Subject"] = f"Daily Browser Cleanup - {computer_name}"
msg["From"] = gmail_user
msg["To"] = "Undisclosed Recipients"


# Send Email
try:

    with smtplib.SMTP("smtp.gmail.com", 587) as server:

        server.starttls()

        server.login(
            gmail_user,
            gmail_app_password
        )

        server.sendmail(
            gmail_user,
            gmail_bcc,
            msg.as_string()
        )


    print("Email sent successfully!")


except Exception as e:

    print(f"Failed to send email: {e}")