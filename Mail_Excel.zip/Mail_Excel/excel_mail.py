import pandas as pd
import random
import os
import smtplib
from faker import Faker
from datetime import datetime
from email.message import EmailMessage


# ==========================
# CONFIGURATION
# ==========================

OUTPUT_FOLDER = "Generated_Files"

# Email Configuration
SMTP_SERVER = "smtp.gmail.com"
SMTP_PORT = 587

SENDER_EMAIL = "richard.kiwal3@gmail.com"
SENDER_PASSWORD = "nroijhaugdicjpmk"

RECEIVERS = [
     "rich1.kiwale@gmail.com",
     "richardkiwale74@gmail.com",
]

SEND_EMAIL = True   # Change to False if you don't want email


# ==========================
# CREATE FOLDER
# ==========================

if not os.path.exists(OUTPUT_FOLDER):
    os.makedirs(OUTPUT_FOLDER)


fake = Faker()


# ==========================
# GENERATE RANDOM EXCEL
# ==========================

def create_excel():

    data = []

    for i in range(10):

        data.append({
            "ID": i + 1,
            "Name": fake.name(),
            "Email": fake.email(),
            "Phone": fake.phone_number(),
            "Department": random.choice(
                ["IT", "Finance", "HR", "Sales", "Support"]
            ),
            "Amount": random.randint(1000, 50000),
            "Date": datetime.now().strftime("%Y-%m-%d")
        })


    df = pd.DataFrame(data)


    filename = datetime.now().strftime(
        "%a%d%m%Y-%H-%M.xlsx"
    )


    filepath = os.path.join(
        OUTPUT_FOLDER,
        filename
    )


    df.to_excel(
        filepath,
        index=False
    )


    print(f"Excel created: {filepath}")

    return filepath



# ==========================
# SEND EMAIL
# ==========================


def send_email(filepath):

    msg = EmailMessage()

    msg["From"] = SENDER_EMAIL
    msg["To"] = ", ".join(RECEIVERS)
    msg["Subject"] = "AUTOMATION TESTING"

    msg.set_content("""
Hello,

Please find attached the  Excel .

Regards,
IT Department
    """)


    with open(filepath, "rb") as file:

        msg.add_attachment(
            file.read(),
            maintype="application",
            subtype="xlsx",
            filename=os.path.basename(filepath)
        )


    try:

        with smtplib.SMTP(
            SMTP_SERVER,
            SMTP_PORT
        ) as server:

            server.starttls()

            server.login(
                SENDER_EMAIL,
                SENDER_PASSWORD
            )

            server.send_message(msg)


        print("Email sent successfully")


    except Exception as e:

        print(
            f"Email sending failed: {e}"
        )


# def send_email(filepath):

#     msg = EmailMessage()

#     msg["From"] = SENDER_EMAIL
#     msg["To"] = ", ".join(RECEIVERS)
#     msg["Subject"] = "Automated Random Data Excel Report"


#     msg.set_content(
#         """
# Hello,

# Please find attached the automated Excel report.

# Regards
# Python Automation
#         """
#     )


#     with open(filepath, "rb") as file:

#         data = file.read()

#         filename = os.path.basename(filepath)


#     msg.add_attachment(
#         data,
#         maintype="application",
#         subtype="xlsx",
#         filename=filename
#     )


#     try:

#         server = smtplib.SMTP(
#             SMTP_SERVER,
#             SMTP_PORT
#         )

#         server.starttls()

#         server.login(
#             SENDER_EMAIL,
#             SENDER_PASSWORD
#         )

#         server.send_message(msg)

#         server.quit()

#         print("Email sent successfully")


#     except Exception as e:

#         print(
#             f"Email failed: {e}"
#         )



# ==========================
# MAIN TASK
# ==========================

def task():

    print(
        "Generating Excel..."
    )

    file = create_excel()


    if SEND_EMAIL:

        send_email(file)



# ==========================
# SCHEDULER
# ==========================

# Run every 30 minutes
# ==========================
# RUN ONCE
# ==========================

if __name__ == "__main__":

    print("Script Running...")

    task()

    print("Process completed successfully.")